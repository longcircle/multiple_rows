import "./CarouselTesT.css";
import { useEffect, useRef, useState } from "react";

function CarouselTesT() {
  const container_Carousel = useRef();
  const btn1 = useRef();
  const btn2 = useRef();
  const Dot1 = useRef();
  const Dot2 = useRef();
  const [nowX, setNowX] = useState(0);

  useEffect(() => {
    container_Carousel.current.style.transform = `translateX(${nowX}px)`;
    console.log(`it's work ${nowX}`);
  }, [nowX]);

  // useState 말고 useEffect를 이용해야할듯.
  const Button = (e) => {
    if (parseInt(e.target.value) === 0) {
      setNowX((prop) => 0);
      btn1.current.style.display = "none";
      btn2.current.style.display = "block";
      Dot1.current.style.backgroundColor = "orange";
      Dot2.current.style.backgroundColor = "";
    } else if (parseInt(e.target.value) === -1) {
      setNowX((prop) => e.target.value * 960);
      btn2.current.style.display = "none";
      btn1.current.style.display = "block";
      Dot2.current.style.backgroundColor = "orange";
      Dot1.current.style.backgroundColor = "";
    }
    // console.log(`it's work ${nowX}`);
  };

  return (
    <div className="container">
      <button className="left" onClick={Button} value={0} ref={btn1}></button>
      <button className="right" onClick={Button} value={-1} ref={btn2}></button>
      <div className="body">
        <div className="container_Carousel" ref={container_Carousel}>
          <div className="inner">
            <img
              src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/gwjm44q804mbmvji.jpg?fit=around|600:400&crop=600:400;*,*&output-format=jpg&output-quality=80"
              alt=""
            >
              {/* <a href="mangoplate.com/">
                <span className="title">맛집</span>
                <p className="desc">주소</p>
              </a> */}
            </img>
            <img
              src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/dkiovygfrwyedw_r.jpg?fit=around|600:400&crop=600:400;*,*&output-format=jpg&output-quality=80"
              alt=""
            />
          </div>
          <div className="inner">
            <img
              src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/gwjm44q804mbmvji.jpg?fit=around|600:400&crop=600:400;*,*&output-format=jpg&output-quality=80"
              alt=""
            />
            <img
              src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/dkiovygfrwyedw_r.jpg?fit=around|600:400&crop=600:400;*,*&output-format=jpg&output-quality=80"
              alt=""
            />
          </div>
          <div className="inner">
            <img
              src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/gwjm44q804mbmvji.jpg?fit=around|600:400&crop=600:400;*,*&output-format=jpg&output-quality=80"
              alt=""
            />
            <img
              src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/gwjm44q804mbmvji.jpg?fit=around|600:400&crop=600:400;*,*&output-format=jpg&output-quality=80"
              alt=""
            />
          </div>
          <div className="inner">
            <img
              src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/dkiovygfrwyedw_r.jpg?fit=around|600:400&crop=600:400;*,*&output-format=jpg&output-quality=80"
              alt=""
            />
            <img
              src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/gwjm44q804mbmvji.jpg?fit=around|600:400&crop=600:400;*,*&output-format=jpg&output-quality=80"
              alt=""
            />
          </div>
          <div className="inner">
            <img
              src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/dkiovygfrwyedw_r.jpg?fit=around|600:400&crop=600:400;*,*&output-format=jpg&output-quality=80"
              alt=""
            />
            <img
              src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/gwjm44q804mbmvji.jpg?fit=around|600:400&crop=600:400;*,*&output-format=jpg&output-quality=80"
              alt=""
            />
          </div>
          <div className="inner">
            <img
              src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/dkiovygfrwyedw_r.jpg?fit=around|600:400&crop=600:400;*,*&output-format=jpg&output-quality=80"
              alt=""
            />
            <img
              src="https://mp-seoul-image-production-s3.mangoplate.com/keyword_search/meta/pictures/gwjm44q804mbmvji.jpg?fit=around|600:400&crop=600:400;*,*&output-format=jpg&output-quality=80"
              alt=""
            />
          </div>
        </div>
      </div>
      <div className="dotBtn_container">
        <button
          value={0}
          onClick={Button}
          ref={Dot1}
          style={{ backgroundColor: "orange" }}
        ></button>
        <button value={-1} onClick={Button} ref={Dot2}></button>
      </div>
    </div>
  );
}

export default CarouselTesT;
